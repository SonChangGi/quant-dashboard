import concurrent.futures,json,urllib.request,urllib.error,datetime,pathlib,re,time
base=pathlib.Path(__file__).parent
repos=['shadcn-ui/ui','DavidHDev/react-bits','magicuidesign/magicui','motiondivision/motion','radix-ui/primitives','chakra-ui/ark','chakra-ui/zag','cschroeter/park-ui','amzn/style-dictionary','TanStack/table','glideapps/glide-data-grid','ag-grid/ag-grid','finos/perspective','observablehq/plot','f5/unovis','plouc/nivo','recharts/recharts','apache/echarts','vega/vega-lite','xyflow/xyflow','visgl/deck.gl','antvis/G2','ant-design/ant-design','mui/material-ui','carbon-design-system/carbon']
def get(url):
 try:
  r=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'quant-design-research','Accept':'application/vnd.github+json'}),timeout=25)
  return r.read().decode(),dict(r.headers)
 except Exception as e:return None,{'error':str(e)}
def fetch(repo):
 now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 raw,h=get('https://api.github.com/repos/'+repo)
 if not raw:return {'repo':repo,'error':h}
 d=json.loads(raw);name=repo.replace('/','--');(base/(name+'.json')).write_text(raw)
 rr,rh=get('https://api.github.com/repos/'+repo+'/releases/latest')
 release=json.loads(rr) if rr else None
 if rr:(base/(name+'--release.json')).write_text(rr)
 branch=d['default_branch']
 readme,rhh=get(f'https://raw.githubusercontent.com/{repo}/{branch}/README.md')
 if readme:(base/(name+'--README.md')).write_text(readme)
 return {'repo':repo,'checkedAt':now,'metadata':d,'latestRelease':{k:release.get(k) for k in ['tag_name','published_at','html_url','prerelease']} if release else None,'releaseError':rh.get('error'),'readme':bool(readme),'rateRemaining':h.get('X-RateLimit-Remaining')}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:results=list(ex.map(fetch,repos))
(base/'metadata.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
for r in results:
 d=r.get('metadata',{}); print(r['repo'],d.get('stargazers_count'),d.get('pushed_at'),r.get('latestRelease'))
for lang in ['','typescript','javascript']:
 url='https://github.com/trending/'+lang+'?since=weekly';body,h=get(url)
 if body:(base/('trending-'+(lang or 'all')+'.html')).write_text(body)
 print('trending',lang,len(body or ''),h.get('error'))
