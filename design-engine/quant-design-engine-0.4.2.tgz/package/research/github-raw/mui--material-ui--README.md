<!-- lint disable mui-first-block-heading -->
<!-- #host-reference -->

<p align="center">
  <a href="https://next.mui.com/core/" target="_blank"><img width="150" height="133" src="https://next.mui.com/static/logo.svg" alt="Material UI logo"></a>
</p>

<h1 align="center">Material UI</h1>

<div align="center">

[![license](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![npm latest package](https://img.shields.io/npm/v/@mui/material/latest.svg)](https://www.npmjs.com/package/@mui/material)
[![npm next package](https://img.shields.io/npm/v/@mui/material/next.svg)](https://www.npmjs.com/package/@mui/material)
[![npm downloads](https://img.shields.io/npm/dm/@mui/material.svg)](https://www.npmjs.com/package/@mui/material)
[![GitHub branch status](https://img.shields.io/github/checks-status/mui/material-ui/HEAD)](https://github.com/mui/material-ui/commits/HEAD/)
[![Coverage Status](https://img.shields.io/codecov/c/github/mui/material-ui.svg)](https://app.codecov.io/gh/mui/material-ui/)
[![Follow on X](https://img.shields.io/twitter/follow/MaterialUI.svg?label=follow+Material+UI)](https://x.com/MaterialUI)
[![Renovate status](https://img.shields.io/badge/renovate-enabled-brightgreen.svg)](https://github.com/mui/material-ui/issues/27062)
[![Average time to resolve an issue](https://isitmaintained.com/badge/resolution/mui/material-ui.svg)](https://isitmaintained.com/project/mui/material-ui 'Average time to resolve an issue')
[![Open Collective backers and sponsors](https://img.shields.io/opencollective/all/mui-org)](https://opencollective.com/mui-org)
[![OpenSSF Best Practices](https://www.bestpractices.dev/projects/1320/badge)](https://www.bestpractices.dev/projects/1320)

</div>

[Material UI](https://next.mui.com/material-ui/) is a comprehensive library of React components that features our independent implementation of Google's [Material Design](https://m2.material.io/design/introduction/) system.
It's trusted by some of the world's greatest product teams because it's been rigorously battle-tested through more than a decade of development by thousands of open-source contributors.

Material UI's core functionality is extended by [MUI X](https://github.com/mui/mui-x), a suite of complex components for advanced use cases.

## Documentation

Get started in the [Material UI documentation](https://next.mui.com/material-ui/getting-started/).

<details>
  <summary>Older versions</summary>

- **[v5.x](https://v5.mui.com/)** ([Upgrading from v5 to v6](https://next.mui.com/material-ui/migration/upgrade-to-v6/))
- **[v4.x](https://v4.mui.com/)** ([Upgrading from v4 to v5](https://next.mui.com/material-ui/migration/migration-v4/))
- **[v3.x](https://v3.mui.com/)** ([Upgrading from v3 to v4](https://next.mui.com/material-ui/migration/migration-v3/))
- **[v0.x](https://v0.mui.com/)** ([Upgrading to v1](https://next.mui.com/material-ui/migration/migration-v0x/))

</details>

**Note:** `@next` points to pre-releases.
Use `@latest` for the latest stable release.

## Sponsors

### Diamond 💎

<p>
  <a href="https://www.doit.com/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank"><img height="128" width="128" src="https://next.mui.com/static/sponsors/doit-square.svg" alt="doit" title="Management Platform for Google Cloud and AWS" loading="lazy" /></a>
</p>

Diamond sponsors are those who have pledged $1,500/month or more to MUI.

### Gold 🏆

via [Open Collective](https://opencollective.com/mui-org) or via [Patreon](https://www.patreon.com/oliviertassinari)

<p>
  <a href="https://tidelift.com/" rel="sponsored" target="_blank"><img height="96" width="96" src="https://avatars.githubusercontent.com/u/30204434?s=288" alt="tidelift.com" title="Tidelift: Enterprise-ready open-source software." loading="lazy" /></a>
  &nbsp;
  <a href="https://www.dialmycalls.com/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank"><img height="96" width="96" src="https://images.opencollective.com/dialmycalls/f5ae9ab/avatar/288.png" alt="dialmycalls.com" title="DialMyCalls: Send text messages, calls, and emails." loading="lazy" /></a>
  &nbsp;
</p>

<p>
  <a href="https://goread.io/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">Goread.io</a>
  &nbsp;
  <a href="https://poprey.com/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">Poprey</a>
  &nbsp;
  <a href="https://www.socialwick.com/instagram/followers/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">SocialWick</a>
  &nbsp;
 <a href="https://www.follower24.de/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">Follower24</a>
  &nbsp;
  <a href="https://views4you.com/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">Views4You</a>
  &nbsp;
  <a href="https://instant-famous.com/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">Instant Famous</a>
  &nbsp;
  <a href="https://tokboostly.com/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">TokBoostly</a>
  &nbsp;
  <a href="https://www.socialboosting.com/?utm_source=mui.com&utm_medium=referral&utm_content=readme" rel="sponsored" target="_blank">SocialBoosting</a>
  &nbsp;
</p>

Gold sponsors are those who have pledged $500/month or more to MUI.

### More backers

See the full list of [our backers](https://next.mui.com/material-ui/discover-more/backers/).

## Questions

For how-to questions that don't involve making changes to the code base, please use [Stack Overflow](https://stackoverflow.com/questions/) instead of GitHub issues.

## Examples

<!-- #target-branch-reference -->

Our documentation features [a collection of example projects](https://github.com/mui/material-ui/tree/master/examples).

## Premium templates

You can find complete templates and themes in the [MUI Store](https://mui.com/store/?utm_source=docs&utm_medium=referral&utm_campaign=readme-store).

## Contributing

Read the [contributing guide](/CONTRIBUTING.md) to learn about our development process, how to propose bug fixes and improvements, and how to build and test your changes.

Contributing is about more than just issues and pull requests!
There are many other ways to [support Material UI](https://next.mui.com/material-ui/getting-started/faq/#mui-is-an-awesome-organization-how-can-i-support-it) beyond contributing to the code base.

## Changelog

The [changelog](https://github.com/mui/material-ui/releases) is regularly updated to reflect what's changed in each new release.

## Roadmap

Future plans and high-priority features and enhancements can be found in the [roadmap](https://next.mui.com/material-ui/discover-more/roadmap/).

## License

This project is licensed under the terms of the [MIT license](/LICENSE).

## Security

For details on supported versions and contact information for reporting security issues, please refer to the [security policy](https://github.com/mui/material-ui/security/policy).

## Sponsoring services

These great services sponsor MUI's core infrastructure:

<div>
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://next.mui.com/static/readme/github-darkmode.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://next.mui.com/static/readme/github-lightmode.svg">
  <img alt="GitHub logo" src="https://next.mui.com/static/readme/github-lightmode.svg" width="80" height="43">
</picture>

[GitHub](https://github.com/) lets us host the Git repository and coordinate contributions.

</div>

<div>
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://next.mui.com/static/readme/netlify-darkmode.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://next.mui.com/static/readme/netlify-lightmode.svg">
  <img alt="Netlify logo" src="https://next.mui.com/static/readme/netlify-lightmode.svg" width="100" height="27">
</picture>

[Netlify](https://www.netlify.com/) lets us distribute the documentation.

</div>

<div>
<img loading="lazy" alt="CodeCov logo" src="https://avatars.githubusercontent.com/u/8226205?s=105" width="35" height="35">

[CodeCov](https://about.codecov.io/) lets us monitor test coverage.

</div>
